# Super-Message-Board

## **Setup Instructions**
In order to use this project start at homePage.html or settings.html, which can be found in their respective folders.

In order to navigate the project used the bottom navigation bar. 

In order to reach settings from the navigation bar. Tap/Click the UMD logo in the bottom right hand corner.